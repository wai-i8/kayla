import { chromium } from 'playwright-core';
import path from 'node:path';

const root = 'C:\\Users\\lauka\\Downloads\\KAYLA';
const browser = await chromium.launch({
  executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  headless: true,
  args: ['--no-sandbox'],
});

const results = {};
try {
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    deviceScaleFactor: 1,
    isMobile: true,
    hasTouch: true,
  });
  const page = await context.newPage();
  const consoleErrors = [];
  page.on('console', (message) => {
    if (message.type() === 'error') consoleErrors.push(message.text());
  });
  page.on('pageerror', (error) => consoleErrors.push(error.message));

  await page.goto('http://127.0.0.1:5173/?demo=1', { waitUntil: 'networkidle' });
  await page.getByTestId('recent-records').waitFor({ state: 'visible' });
  const reminderSection = page.getByTestId('daily-baby-reminders');
  await reminderSection.waitFor({ state: 'visible' });
  results.dailyReminderCards = await reminderSection.locator('.daily-reminder-row').count();
  results.dailyReminderViewAll = await page.getByTestId('view-all-baby-reminders').isVisible();
  await page.getByTestId('view-all-baby-reminders').click();
  await page.getByRole('dialog', { name: '按 BB 而家嘅階段', exact: true }).waitFor({ state: 'visible' });
  results.allReminderRows = await page.locator('.reminder-all-item').count();
  await page.getByRole('button', { name: '關閉全部提醒', exact: true }).click();
  await reminderSection.getByRole('button', { name: '了解多啲', exact: true }).first().click();
  await page.locator('.reminder-dialog:not(.reminder-all-dialog)').waitFor({ state: 'visible' });
  results.reminderDetailOpened = await page.getByText('一般育兒資訊，不取代', { exact: false }).isVisible();
  await page.getByRole('button', { name: '關閉提醒詳情', exact: true }).click();
  results.mobileHorizontalOverflow = await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth);
  const recentIds = ['temperature', 'sleep', 'medicine', 'weight'];
  const recentBoxes = [];
  const recentText = {};
  for (const type of recentIds) {
    const tile = page.getByTestId(`open-records-${type}`);
    recentBoxes.push(await tile.boundingBox());
    recentText[type] = (await tile.innerText()).replace(/\s+/g, ' ').trim();
  }
  results.recentSameRow = recentBoxes.every((box) => box && Math.abs(box.y - recentBoxes[0].y) < 2);
  results.recentValues = recentText;
  results.albumIconSize = await page.getByTestId('mobile-open-photos').boundingBox();
  await page.screenshot({ path: path.join(root, '.browser-test-home.png'), fullPage: true });

  for (const type of recentIds) {
    await page.getByTestId(`open-records-${type}`).click();
    await page.getByTestId(`records-filter-${type}`).waitFor({ state: 'visible' });
    const pressed = await page.getByTestId(`records-filter-${type}`).getAttribute('aria-pressed');
    if (pressed !== 'true') throw new Error(`${type} filter was not activated`);
    await page.getByRole('button', { name: '今日', exact: true }).click();
    await page.getByTestId('recent-records').waitFor({ state: 'visible' });
  }
  results.recentLinks = 'all four filters passed';

  await page.getByTestId('mobile-open-photos').click();
  await page.getByRole('heading', { name: 'Kayla 相簿', exact: true }).waitFor({ state: 'visible' });
  results.emptyAlbum = await page.getByText('相簿仲係空嘅', { exact: true }).isVisible();
  await page.screenshot({ path: path.join(root, '.browser-test-album-empty.png'), fullPage: true });

  await page.getByTestId('open-photo-editor').click();
  await page.getByRole('dialog', { name: '新增相片', exact: true }).waitFor({ state: 'visible' });
  results.photoSources = {
    camera: await page.getByRole('button', { name: /即時影相/ }).isVisible(),
    gallery: await page.getByRole('button', { name: /相簿選擇/ }).isVisible(),
  };
  const galleryInput = page.locator('input[type="file"]:not([capture])');
  if (await galleryInput.count() !== 1) throw new Error('Expected one gallery input');
  await galleryInput.setInputFiles(path.join(root, 'public', 'kayla-album.webp'));
  await page.getByAltText('準備上傳嘅相片預覽').waitFor({ state: 'visible' });
  await page.getByPlaceholder('例如：第一次返到屋企').fill('本機相簿測試');
  await page.getByRole('button', { name: '儲存到私人相簿', exact: true }).click();
  await page.locator('.photo-card').waitFor({ state: 'visible', timeout: 20_000 });
  results.demoPhotoAdded = await page.getByText('本機相簿測試', { exact: true }).isVisible();
  await page.screenshot({ path: path.join(root, '.browser-test-album-filled.png'), fullPage: true });

  await page.locator('.photo-card').click();
  await page.getByRole('dialog', { name: '查看相片', exact: true }).waitFor({ state: 'visible' });
  results.viewerOpened = await page.getByAltText(/本機相簿測試/).isVisible();
  await page.getByRole('button', { name: '刪除相片', exact: true }).click();
  await page.getByRole('button', { name: '永久刪除', exact: true }).click();
  await page.getByText('相簿仲係空嘅', { exact: true }).waitFor({ state: 'visible' });
  results.demoPhotoDeleted = true;

  results.consoleErrors = consoleErrors;
  await context.close();

  const desktop = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const desktopPage = await desktop.newPage();
  await desktopPage.goto('http://127.0.0.1:5173/?demo=1', { waitUntil: 'networkidle' });
  results.desktopAlbumIconVisible = await desktopPage.getByTestId('desktop-open-photos').isVisible();
  await desktopPage.screenshot({ path: path.join(root, '.browser-test-desktop.png'), fullPage: true });
  await desktop.close();

  console.log(JSON.stringify(results, null, 2));
} finally {
  await browser.close();
}
